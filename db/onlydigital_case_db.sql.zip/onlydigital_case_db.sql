-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Июн 11 2023 г., 22:22
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `onlydigital_case_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(1478) NOT NULL,
  `email` varchar(40) NOT NULL,
  `number` decimal(10,0) NOT NULL COMMENT 'phone number',
  `pass` char(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `number`, `pass`) VALUES
(1, 'test', 'test@mail.com', '1231234567', '098f6bcd4621d373cade4e832627b4f6'),
(2, 'Name1', 'name1@mail.com', '1234567890', 'c4ca4238a0b923820dcc509a6f75849b'),
(3, 'Name2', 'name2@mail.com', '1234567891', 'c81e728d9d4c2f636f067f89cc14862c'),
(5, 'Name3', 'name3@mail.com', '1234567893', 'eccbc87e4b5ce2fe28308fd9f2a7baf3'),
(6, 'Name4', 'name4@mail.com', '1234567894', 'a87ff679a2f3e71d9181a67b7542122c'),
(7, 'Name5', 'name5@mail.com', '1234567895', 'e4da3b7fbbce2345d7772b0674a318d5'),
(8, 'Name6', 'name68@mail.com', '1234567896', '1679091c5a880faf6fb5e6087eb1b2dc'),
(9, 'Name7', 'name7@mail.com', '1234567897', '8f14e45fceea167a5a36dedd4bea2543'),
(10, 'Name8', 'name8@mail.com', '1231234568', 'c9f0f895fb98ab9159f51fd0297e236d'),
(22, 'admin', 'admin@mail.com', '1111111111', '21232f297a57a5a743894a0e4a801fc3');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `number` (`number`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
